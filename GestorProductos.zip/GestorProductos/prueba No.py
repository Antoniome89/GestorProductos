from tkinter import ttk
from tkinter import *
import sqlite3

class Prueba():

# Tabla de Productos
style = ttk.Style()
style.configure("mystyle.Treeview", highlightthickness=0, bd=0, font=("Calibri", 11))
style.configure("mystyle.Treeview.Heading", font=("Calibri", 12, "bold"))
style.layout("mystyle.Treeview", [("mystyle.Treeview.treearea", {"sticky": "nswe"})])

# Estructura de la tabla
self.tabla = ttk.Treeview(height=20, columns=3, style="mystyle.Treeview")
self.tabla.grid(row=6, column=0, columnspan=3)
self.tabla.heading("#0", text="Nombre", anchor=CENTER)
self.tabla.heading("#1", text="Precio", anchor=CENTER)
self.tabla.heading("#2", text="Categoría", anchor=CENTER)